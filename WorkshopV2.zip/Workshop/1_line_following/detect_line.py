#------------------------------------------------------------------------------#
#------------------------------Line Detection----------------------------------#
#------------------------------------------------------------------------------#
# Detects a shape from the camera image using HSV thresholding

#===============================================================================
#region: Python imports
#-------------------------------------------------------------------------------

import cv2
import os
import sys
import numpy as np
from pal.utilities.timing import Timer
from pal.products.sensors import SensorsCamera, SensorsDisplay

# imports from parent directory
parent_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(parent_path)
from mobile_robot_functions import MDLVision, MDLDisplayFormat
# endregion

#===============================================================================
#region: Initialize constants and variables
#-------------------------------------------------------------------------------
TOTAL_RUNTIME = 1200 # will run for this duration in seconds
FRAME_RATE = 30
IMAGE_SIZE = [640,480]
MAIN_LOOP_RATE = 90

sampleCount = 0 
centroid_loc = np.array([0,0], dtype=int)
x, y, w, h = 0,0,0,0
#endregion

#===============================================================================
#region: Initialization
#-------------------------------------------------------------------------------

timer = Timer(sampleRate=MAIN_LOOP_RATE, totalTime=TOTAL_RUNTIME)
vision = MDLVision(IMAGE_SIZE[0], IMAGE_SIZE[1])
display = MDLDisplayFormat(IMAGE_SIZE[0], IMAGE_SIZE[1])

with  (SensorsCamera(frameWidth=IMAGE_SIZE[0],
                    frameHeight=IMAGE_SIZE[1],
                    frameRate=FRAME_RATE,
                    cameraID=0) as camera, 
                    SensorsDisplay() as lcd): # modify cameraID if needed
    #endregion

    while timer.check():

        currentTime = timer.get_current_time()

        #=======================================================================
        #region: Image preprocessing and line detection
        #-----------------------------------------------------------------------
        # read image
        newFrame = camera.read()
        if newFrame:
            image = camera.imageData

            # *************************** PART A ****************************** 
            # Modify the HSV thresholds as needed to detect the line robustly
            # under your lighting conditions

            imageThreshold = vision.hsv_threshold(image,
                                                   hsvLow=np.array([15,65,150]), 
                                                   hsvHigh=np.array([40,220,255]))
            #blue
            #100, 130, 85
            #115, 185, 150
            
            #black
            #120, 20, 25
            #180, 85, 55

            #yellow
            #15, 65, 230
            #30, 85, 255

            # ******************************************************************

            col, row, left, top, width, height = vision.image_find_objects(imageThreshold[0:int(IMAGE_SIZE[1]/2),:], 
                                                                           connectivity = 8, 
                                                                           minArea = 700, 
                                                                           maxArea = 30000)

            if col is not None:
                centroid_loc = [int(col), int(row)]
                x,y,w,h = left, top, width, height
            
            #endregion

            #===================================================================
            #region: Display for validation and visualization
            #-------------------------------------------------------------------
            if sampleCount%3==0:
                # show bounding box and centroid of detected shape
                marked_image = display.draw_bounding_box(image,centroid_loc, x,y,w,h)
            
                # display individual HSV channels
                imgHSV = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
                imgH, imgS, imgV = cv2.split(imgHSV)
                concatHSV = cv2.hconcat([imgH, imgS, imgV])

                # label each hsv channel 
                for i, label in enumerate(["HUE", "SATURATION", "VALUE"]):
                    cv2.putText(
                        img = concatHSV,
                        text = label,
                        org = (i*IMAGE_SIZE[0]+10, 40),
                        fontFace = cv2.FONT_HERSHEY_SIMPLEX,
                        fontScale = 1.5,
                        color = (255,255,255),
                        thickness = 2
                    )

                cv2.imshow("HSV Image Channels", cv2.resize(src = concatHSV, 
                                                            dsize = (int(IMAGE_SIZE[0]*1.2), 
                                                                    int(IMAGE_SIZE[1]*0.4))))

                # display binary thresholded image
                imageThreshold = cv2.cvtColor(imageThreshold, cv2.COLOR_GRAY2BGR) # convert to BGR for concatenation
                concatThreshold = cv2.hconcat([image, imageThreshold, marked_image])

                # label each image 
                for i, label in enumerate(["RAW CAMERA IMAGE", "THRESHOLDED IMAGE", "DETECTED OBJECT"]):
                    cv2.putText(
                        img = concatThreshold,
                        text = label,
                        org = (i*IMAGE_SIZE[0]+10, 40),
                        fontFace = cv2.FONT_HERSHEY_SIMPLEX,
                        fontScale = 1.5,
                        color = (255,255,255),
                        thickness = 2
                    )

                cv2.imshow("Image Thresholding", cv2.resize(src = concatThreshold, 
                                                            dsize = (int(IMAGE_SIZE[0]*1.2), 
                                                                    int(IMAGE_SIZE[1]*0.4))))

                # show on sensors device display
                lcd.draw_image(marked_image)
                cv2.waitKey(1)
            #endregion

            sampleCount += 1

        timer.sleep()

cv2.destroyAllWindows()

input ("Press Enter to exit...")