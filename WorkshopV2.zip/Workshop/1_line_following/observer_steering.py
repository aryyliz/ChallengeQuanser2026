#------------------------------------------------------------------------------#
#---------------------Observer - Vision-based Steering-------------------------#
#------------------------------------------------------------------------------#
# Observer for displaying data from vision_based_steering.py

from pal.utilities.probe import Observer

observer = Observer()
observer.add_scope(numSignals=2, 
                name = 'Motor Position',
                signalNames= ['Left Motor (rad)', 'Right Motor (rad)'])
observer.add_scope(numSignals=2, 
                name = 'Motor Speeds',
                signalNames= ['Left Motor (rad/s)', 'Right Motor(rad/s)'])
observer.add_scope(numSignals=2, 
                name = 'Angles',
                signalNames= ['steer_angle/100', 'turnSpdCmd'])
observer.launch()