#------------------------------------------------------------------------------#
#------------------------Observer - Distance Sensing---------------------------#
#------------------------------------------------------------------------------#
# Observer for displaying data from distance_sensing.py

from pal.utilities.probe import Observer

observer = Observer()
observer.add_scope(numSignals = 3, 
                   name = 'Distance',
                   signalNames= ['Ultrasonic', 'IR', 'TOF'])
observer.launch()