#------------------------------------------------------------------------------#
#------------------------------Distance Sensing--------------------------------#
#------------------------------------------------------------------------------#
# Reads distance measurements from the ultrasonic, IR and TOF sensor. 
# For the TOF sensor, it returns the mean of the centre 2x2 measurements

#===============================================================================
#region: Python imports
#-------------------------------------------------------------------------------
import numpy as np
import cv2
import os
import subprocess
import sys

from pal.utilities.probe import Probe
from pal.utilities.timing import Timer
from pal.products.sensors import SensorsTrainer
# endregion

#===============================================================================
#region: Initialize constants and variables
#-------------------------------------------------------------------------------
TOTAL_RUNTIME = 300 # will run for this duration in seconds
SAMPLE_FREQ = 200 # Hz
counter = 0 # counter to track scopes

# for TOF sensor
MAX_TOF = 1.0
MAX_SIGMA = 0.055
MAX_REFLECTANCE = 1.0
MAX_TARGETS = 3

# for other distance sensors
ultrasonicDist = 0
irDist = 0
TOFCenterDist = 0
#endregion

#===============================================================================
#region: Scope setup 
#-------------------------------------------------------------------------------
probe = Probe(ip = 'localhost')
probe.add_scope(numSignals=3, name='Distance')

subprocess.Popen(
    [sys.executable, 
     os.path.join(os.path.dirname(__file__), 'observer_distance_sensing.py')],
    cwd=os.path.dirname(__file__))
while not probe.connected:
    probe.check_connection()
#endregion

#===============================================================================
#region: Initialization
#------------------------------------------------------------------------------
timer = Timer(sampleRate=SAMPLE_FREQ, totalTime=TOTAL_RUNTIME)

with SensorsTrainer(ultraService=1, ultraStart=0.0, ultraLength=5.0) as sensors:
#endregion
    while timer.check():

        currentTime = timer.get_current_time()

        #=======================================================================
        #region: Read sensor data
        #-----------------------------------------------------------------------
        sensors.read_outputs()

        # ultrasonic sensor
        ultrasonicDist = sensors.ultraDistance

        # IR distance sensor
        irRaw = sensors.IRDistance

        # ***************************** PART B *********************************

        # Replace coefficients to convert raw IR reading to distance measurement
        b0 = 0.254
        b1 = -1.186

        # map raw readings to distance measurements
        irDist = b0*np.power(irRaw, b1)
        # **********************************************************************

        # TOF sensor
        # Estimate distance at center of TOF field of view  
        TOFMeasurements = np.flip((sensors.TOFDistance * 
                                   sensors.TOFNumberOfTargets).reshape(8,8), 
                                   axis=0)
        # get mean of 2x2 distance measurements at field of view center
        TOFCenterDist = np.mean((TOFMeasurements[3:4,3:4]).flatten())
        #endregion

        #=======================================================================
        #region: Display data
        #-----------------------------------------------------------------------

        # Reshape TOF measurements to square shape and flip for visualization
        TOFDistancesReshaped   = np.flip(sensors.TOFDistance.reshape(8,8), axis=(0,1))
        TOFReflectanceReshaped = np.flip(sensors.TOFReflectance.reshape(8,8), axis=(0,1))
        TOFSigmaReshaped       = np.flip(sensors.TOFSigma.reshape(8,8), axis=(0,1))
        TOFNumberReshaped      = np.flip(sensors.TOFNumberOfTargets.reshape(8,8), axis=(0,1))

        # Map TOF measurements to uint8 range for greyscale plotting
        TOFDistanceImg    = np.clip(TOFDistancesReshaped*255/MAX_TOF, 0, 255).astype(np.uint8)
        TOFReflectanceImg = np.clip(TOFReflectanceReshaped*255/MAX_REFLECTANCE, 0, 255).astype(np.uint8)
        TOFSigmaImg       = np.clip(TOFSigmaReshaped*255/MAX_SIGMA, 0, 255).astype(np.uint8)
        TOFNumberImg      = np.clip(TOFNumberReshaped*255/MAX_TARGETS, 0, 255).astype(np.uint8)
        
        # update scopes every 10 samples
        if counter%10 == 0:

            # resize images larger for viewing
            TOFDistanceImgResized = cv2.resize(TOFDistanceImg,(200,200), interpolation=cv2.INTER_NEAREST)
            cv2.rectangle(TOFDistanceImgResized, (75,75), (125,125), color=(255,255,255), thickness=2)
            TOFReflectanceImgResized = cv2.resize(TOFReflectanceImg,(200,200), interpolation=cv2.INTER_NEAREST)
            TOFSigmaImgResized = cv2.resize(TOFSigmaImg,(200,200), interpolation=cv2.INTER_NEAREST)
            TOFNumberImgResized = cv2.resize(TOFNumberImg,(200,200), interpolation=cv2.INTER_NEAREST)
        
        if counter%4 == 0:
            # display distance measurements from each sensor
            probe.send(name='Distance', scopeData=(currentTime, [ultrasonicDist, irDist, TOFCenterDist]))
            
            # display each matrix of measured 
            cv2.imshow('Colorized Distance Matrix', TOFDistanceImgResized)
            # cv2.imshow('TOF Reflectance Image', TOFReflectanceImgResized)
            # cv2.imshow('TOF Sigma % Image', TOFSigmaImgResized)
            # cv2.imshow('TOF Number Image', TOFNumberImgResized)
        #endregion    
        counter += 1

        cv2.waitKey(1)
        timer.sleep()

cv2.destroyAllWindows()
# endregion