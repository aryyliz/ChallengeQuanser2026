#------------------------------------------------------------------------------#
#------------------------------IR Calibration----------------------------------#
#------------------------------------------------------------------------------#
# This script is used to calibrate the IR distance sensor. It records a voltage
# for each given distance from the sensor and fits a curve to map the two values


# *********************** How to perform calibration **************************

# You will need a flat object, such as a notebook or tablet.
# Run this script. Following the directions in the terminal output, place your 
# object at each distance from the IR sensor, and press spacebar to record the
# current voltage. 
# 
# Stop the script and copy the calibration coefficients in the terminal output 

# ******************************************************************************

#===============================================================================
#region: Python imports
#-------------------------------------------------------------------------------
import numpy as np
from matplotlib import pyplot as plt
from pal.utilities.timing import Timer
from pal.utilities.keyboard import QKeyboard
from pal.products.sensors import SensorsTrainer
# endregion

#===============================================================================
#region: Initialize constants and variables
#-------------------------------------------------------------------------------
TOTAL_RUNTIME = 600 # seconds
SAMPLE_FREQ = 200 # Hz

# ********************************* PART A *************************************
# These constants define the object distances at which voltages will be sampled  
# The values of STEP_DISTANCE and MAX_DISTANCE can be changed if needed. 

# calibration distances in meters
MIN_DISTANCE = 0.1
STEP_DISTANCE = 0.05 # Move object 5 cm between each sample
MAX_DISTANCE = 0.45 # Measure up to 55 cm from sensor
# ******************************************************************************

counter = 0
sampleNum = 0
data = []
noKill = True
# endregion 

#===============================================================================
#region: Initialization
#-------------------------------------------------------------------------------
     
timer = Timer(sampleRate=SAMPLE_FREQ, totalTime=TOTAL_RUNTIME)
keyboardInput = QKeyboard()

sampleDistances = np.arange(start = MIN_DISTANCE, 
                            stop = MAX_DISTANCE + STEP_DISTANCE, 
                            step = STEP_DISTANCE, 
                            dtype = np.float32) 

print("Press SPACE to record a measurement, a total of ", \
      sampleDistances.size, "will be recorded.")
print(f"\nPlace object at {sampleDistances[sampleNum]:.3f}", \
      "m and press SPACE to record voltage")
       
with SensorsTrainer() as sensors:

    while timer.check() and noKill:

        sensors.read_outputs()
        irReading = sensors.IRDistance

        if counter%30 == 0:
            keyboardInput.update()
            spacebar = keyboardInput.states[keyboardInput.K_SPACE]
            
            if spacebar == 1:
                # record voltage at current distance
                distance = sampleDistances[sampleNum]
                data.append([irReading, distance])

                print(f"\nSample number: {sampleNum+1}",\
                        f"     IR Reading: {irReading:.3f}",
                        f"V    Distance: {distance:.3f} m")

                if sampleNum < sampleDistances.size -1:
                    print(f"\nPlace object at {sampleDistances[sampleNum+1]:.3f}", \
                            "m and press SPACE to record voltage")
                    sampleNum += 1 # go to next sampling distance
                else:
                    noKill = False

        counter += 1
        timer.sleep()
# endregion

#===============================================================================
#region: Curve fitting with linear regression
#-------------------------------------------------------------------------------
  
# convert to numpy array and take log to linearize 
npData = np.log(np.array(data) + 1e-9)  # avoid log(0)
sizeData = np.size(npData, axis=0)

# mean of voltage and distance
m_voltage = np.mean(npData[:,0])
m_distance = np.mean(npData[:,1])

# cross deviation and variance
SS_xy = np.sum(npData[:,0]*npData[:,1]) - sizeData*m_voltage*m_distance
SS_xx = np.sum(npData[:,0]*npData[:,0]) - sizeData*m_voltage*m_voltage   

# regression coefficients
b1 = SS_xy / SS_xx
b0 = m_distance - b1*m_voltage

# return to original scale
b0 = np.exp(b0)
b1 = b1

print(f"Fitted curve: \nDistance = {b0:.3f} * Voltage^({b1:.3f})")
print(f"b0 = {b0:.3f}\nb1 = {b1:.3f}")
# endregion

#===============================================================================
#region: Display recorded points and fitted curve
#-------------------------------------------------------------------------------
voltages = np.linspace(0.4,2.5,100)
distances = b0 * voltages**b1
plt.scatter(np.exp(npData[:,1]), np.exp(npData[:,0]), label="Recorded Data")
plt.plot(distances,voltages, color='red', label="Fitted Curve")
plt.xlabel("Distance (m)")
plt.ylabel("Voltage (V)")
plt.title("IR Calibration")
plt.legend()
plt.show()
#endregion