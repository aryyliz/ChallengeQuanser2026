import numpy as np
import cv2

from pal.utilities.math import Calculus, Filter
from quanser.image_processing import Lidar2DMatchScansGrid

class MDLVision():
    """ This class contains vision processing functions for line following"""
    def __init__(self, width, height):
        self.IMAGE_WIDTH = width
        self.IMAGE_HEIGHT = height
    
    def hsv_threshold(self, image, hsvLow, hsvHigh):
        """
        This function converts a BGR image to HSV andthresholds it based on the 
        provided HSV thresholds. Returns the binary image from thresholding.

        Parameters:
            image: BGR image
            hsvLow: lower HSV threshold (array-like of shape (3,))
            hsvHigh: upper HSV threshold (array-like of shape (3,))
        
        Returns:
            binary: binary image from HSV thresholding
        """
        image_hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        threshold_binary = cv2.inRange(image_hsv, hsvLow, hsvHigh)
        binary_cleaned = cv2.morphologyEx(src = threshold_binary,
                                          op = cv2.MORPH_OPEN,
                                          kernel = np.ones((3,3),np.uint8))

        return binary_cleaned
    
    def image_find_objects(self, image, connectivity, minArea, maxArea):
        """
        This function implements connected component labeling on the provided
        image with the desired connectivity. From the list of blobs detected,
        it returns the first blob within the desired area range. Returns the column and row location
        of the blob centroid, as well as the blob's area.

        Parameters:
            image: image
            connectivity: connectivity
            minArea: minimum area
            maxArea: maximum area

        Returns:
            tuple: (col, row, area, left, top, width, height)
                col (int or None): column coordinate of centroid, or None if no object found
                row (int or None): row coordinate of centroid, or None if no object found
                left (int or None): left of bounding box, or None if no object found
                top (int or None): top of bounding box, or None if no object found
                width (int or None): width of bounding box, or None if no object found
                height (int or None): height of bounding box, or None if no object found
        """

        _, _, values, centroids = cv2.connectedComponentsWithStats(image, 
                                                                   connectivity=connectivity, 
                                                                   ltype=cv2.CV_32S)

        for idx, value in enumerate(values):
            
            if (idx> 0 
                    and value[cv2.CC_STAT_AREA] > minArea
                    and value[cv2.CC_STAT_AREA] < maxArea):
                col, row = centroids[idx]
                left = value[cv2.CC_STAT_LEFT]
                top = value[cv2.CC_STAT_TOP]
                width = value[cv2.CC_STAT_WIDTH]
                height = value[cv2.CC_STAT_HEIGHT]
                break
            else:
                col = None
                row = None
                left = None
                top = None
                width = None
                height = None

        return col, row, left, top, width, height 
    
    def centroid_to_steering_error(self, col, row):
        """
        This function finds the steering error from the centroid location. 
        The error is then passed to a steering controller to calculate a turn 
        speed command.

        Parameters:
            col (int): column coordinate of centroid
            row (int): row coordinate of centroid

        Returns:
            error (float): steering error
        """
        #***********************************************************************
        # Implement this function to calculate the steering error from the 
        # centroid location of the detected line. This error will be passed to 
        # the PID controller to calculate a turn speed command.

        #region: sample solution
        #error = horizontal distance from center 
        error = self.IMAGE_WIDTH/2-col
        #endregion

        #error = 0
        # **********************************************************************
        return error
    
    
class MDLDisplayFormat():
    """ This is a helper class for formatting the display of module outputs"""
    
    def __init__(self, width, height):
        """ Initializes the display formatting parameters

        Parameters:
            width (int): width of the image for display formatting
            height (int): height of the image for display formatting
        """
        self.IMAGE_WIDTH = width
        self.IMAGE_HEIGHT = height

    def draw_bounding_box(self, image, centroid_loc, x,y,w,h):
        """ This function draws a bounding box and centroid on the input image,
        with formatting scaled to the image size
        Parameters:
            image: input image
            centroid_loc: location of the centroid
            x (int): left coordinate of the bounding box
            y (int): top coordinate of the bounding box
            w (int): width of the bounding box
            h (int): height of the bounding box
        Returns:            
            newImg: image with bounding box and centroid drawn on it
        """
        lineWidth = int(self.IMAGE_HEIGHT/100) # scaled for image size 
        newImg = image.copy()
        newImg = cv2.circle(newImg, 
                            center = centroid_loc, 
                            radius = 4,
                            color = (0,0,255),
                            thickness = lineWidth)
        cv2.rectangle(newImg, 
                      pt1 = (x,y), 
                      pt2 = (x+w, y+h), 
                      color = (0,0,255), 
                      thickness = lineWidth)
        return newImg
    
    def draw_arrow(self, image, angle):
        """ This function draws an arrow from the center of the image to the 
        steering angle, with formatting scaled to the image size 

        Parameters:
            image: input image
            angle: steering angle to draw arrow for (radians)
        Returns:
            newImg: image with arrow drawn on it
        """
        halfH       = int(self.IMAGE_HEIGHT/2)
        halfW       = int(self.IMAGE_WIDTH/2)
        lineWidth   = int(self.IMAGE_HEIGHT/100) 
        arrowLength = int(self.IMAGE_HEIGHT/4)

        newImg = image.copy()
        cv2.arrowedLine(img = newImg, 
                        pt1 = (halfW, halfH), 
                        pt2 = (halfW - int(arrowLength*np.sin(angle)),  
                               halfH - int(arrowLength*np.cos(angle))), 
                        color = (255,0,0), 
                        thickness = lineWidth, 
                        tipLength = 0.2)
        return newImg
    
    def visualizeAngle(self,image, currentAngle, radius, color):
        """ This function draws a horizontal line and arc to visualize the 
        roll angle from IMU measurements

        Parameters:
            image: input image
            currentAngle: angle span of arc
            radius: radius of arc
            color: color of arc
        Returns:
            image: image with arrow drawn on it
        """
        halfH       = int(self.IMAGE_HEIGHT/2)
        halfW       = int(self.IMAGE_WIDTH/2)
        arcRadius  = np.clip(radius - 60, 30, 200)
        image=cv2.line(img = image, 
                        pt1 = (halfW, halfH), 
                        pt2 = (halfW + int(radius*np.cos(currentAngle*np.pi/180)),  
                                halfH - int(radius*np.sin(currentAngle*np.pi/180))), 
                        color = color, 
                        thickness = 3)
        image=cv2.line(img = image, 
                        pt1 = (halfW, halfH), 
                        pt2 = (halfW - int(radius*np.cos(currentAngle*np.pi/180)),  
                                halfH + int(radius*np.sin(currentAngle*np.pi/180))), 
                        color = color, 
                        thickness = 3)
        
        image=cv2.ellipse(img=image, 
                    center=(halfW, halfH),
                    axes = (arcRadius,arcRadius), 
                    angle = 0,
                    startAngle = 0,
                    endAngle = -currentAngle,
                    color = color,
                    thickness = 3)
        image=cv2.ellipse(img=image, 
                    center=(halfW, halfH),
                    axes = (arcRadius,arcRadius), 
                    angle = 180,
                    startAngle = 0,
                    endAngle = -currentAngle,
                    color = color,
                    thickness = 3)
        return image
    
    def visualizePitch(self,image, rollAngle, pitchAngle, radius, color):
        """ This function draws an arc with a specified radius and angle span.
        It is used for visualizing the pitch angle from IMU measurements

        Parameters:
            image: input image
            currentAngle: angle span of arc
            radius: radius of arc
            color: color of arc
        Returns:
            image: image with arrow drawn on it
        """
        halfH       = int(self.IMAGE_HEIGHT/2)
        halfW       = int(self.IMAGE_WIDTH/2)
        rad_w = int(90.0 + abs(pitchAngle))
        rad_h = int(90.0 - abs(pitchAngle))
        arcRadius  = radius - 30

        image=cv2.line(img = image, 
                        pt1 = (halfW, halfH), 
                        pt2 = (halfW - int(rad_h*np.sin(rollAngle*np.pi/180)),  
                                halfH - int(rad_h*np.cos(rollAngle*np.pi/180))), 
                        color = color, 
                        thickness = 3)
        image=cv2.line(img = image, 
                        pt1 = (halfW, halfH), 
                        pt2 = (halfW + int(rad_h*np.sin(rollAngle*np.pi/180)),  
                                halfH + int(rad_h*np.cos(rollAngle*np.pi/180))), 
                        color = color, 
                        thickness = 3)

        image=cv2.ellipse(img=image, 
                    center=(halfW, halfH),
                    axes = (rad_w, rad_h), 
                    angle = -rollAngle,
                    startAngle = 0,
                    endAngle = 360,
                    color = color,
                    thickness = 3)


        return image

class MDLMovement():
    """ This class contains the functions for differential drive kinematics """

    def __init__(self, whRadius, whDist):
        self.WHEEL_RADIUS = whRadius      # wheel radius (meters)
        self.WHEEL_DIST = whDist          # distance between wheel contact points on the ground (meters)
        # self.ENCODER_COUNTS = encCounts  # encoder counts per channel
        # self.ENCODER_MODE = encMode      # multiplier for a quadrature encoder

    def inverse_velocity_kinematics(self, forSpd, turnSpd):
        """ Inverse velocity kinematics for a differential drive system
        
        Parameters:
            forSpd: body forward speed (m/s)
            turnSpd: body turn speed (rad/s)

        Returns:
            wL: Left wheel speed (rad/s)
            wR: right wheel speed (rad/s)

       """
        # Implement this function to calculate the left and right wheel
        # speeds for a given forward speed and turn speed

        #region: solution
        vL = forSpd - (turnSpd*self.WHEEL_DIST)/2
        vR = forSpd + (turnSpd*self.WHEEL_DIST)/2

        wL = vL/self.WHEEL_RADIUS
        wR = vR/self.WHEEL_RADIUS
        #endregion

        #wL = 0
        #wR = 0 

        return wL, wR

    def forward_velocity_kinematics(self, wL, wR):
        """ Forward velocity kinematics for a differential drive system
        
        Parameters:
            wL: Left wheel speed (rad/s)
            wR: right wheel speed (rad/s)

        Returns:
            forSpd: body forward speed (m/s)
            turnSpd: body turn speed (rad/s)

       """
        #region: sample solution
        # calculate left and right wheel velocities
        # vL = wL * self.WHEEL_RADIUS
        # vR = wR * self.WHEEL_RADIUS

        # calculate forward and turn speed from wheel velocities
        # forSpd = (vR+vL)/2
        # turnSpd = (vR-vL)/self.WHEEL_DIST

        #endregion

        vL = wL * self.WHEEL_RADIUS
        vR = wR * self.WHEEL_RADIUS

        forSpd = (vR+vL)/2
        turnSpd = (vR-vL)/self.WHEEL_DIST

        # forSpd = 0
        # turnSpd = 0

        return forSpd, turnSpd
    
    def error_to_turn_cmd(self, sampleTime, saturation):
        """ PID controller for error from camera image to turn command 
        
        Parameters:
            sampleTime: sampling time (s)
            saturation: saturation limit for integrator

        Returns:
            tuple: a tuple containing:
                - **turnSpd**: body turn speed command (rad/s)
                
       """

        integrator   = Calculus().integrator(dt=sampleTime, saturation=saturation)
        derivative   = Calculus().differentiator(dt = sampleTime)
        low_pass     = Filter().low_pass_second_order(wn=20, dt=sampleTime)
        next(integrator)
        next(derivative)
        next(low_pass)
        turnSpdCmd = 0
        pError, iError, dError = 0,0,0

        while True:
            error, kP, kI, kD = yield turnSpdCmd, pError, iError, dError
            kP_scaled = kP/1000.0
            kI_scaled = kI/1000.0 
            kD_scaled = kD/1000.0 

            if error is not None:
                error_filtered = low_pass.send(error)
                pError = kP_scaled*error
                iError = kI_scaled*(integrator.send(error))
                dError = kD_scaled*derivative.send(error_filtered)
                turnSpdCmd = pError+ iError + dError  # turn spd command

class MDLFusion():
    def __init__(self):
        pass
    def complementary_filter(self, dt, x0=0):
        """Complementary filter based rate and correction signal
            using a combination of low and high pass on them respectively.

        Parameters
        ----------
            kP: float
                proportional gain
            kI: float
                integral gain
            dt: float
                sampling time (s)
            x0: float
                initial condition for integrator

        Yields
        ---------
            float: filtered output signal
        
        """
        # Receives
        # ---------
        #     tuple[float, float]: (rate, correction)
        #         rate: signal to be low-pass filtered (e.g., from a gyroscope)
        #         correction: signal to be high-pass filtered (e.g., from a camera)
        
        output = 0
        temp = 0
        integratorRate = Calculus().integrator(dt, integrand=0)
        integratorTuner = Calculus().integrator(dt, integrand=x0)
        next(integratorRate)
        next(integratorTuner)
        while True:
            rate, correction, kP, kI = yield output
            error = output - correction
            temp = rate - (kP*error) - kI*(integratorTuner.send(error))
            output = integratorRate.send(temp)

class MDLObstacle():
    def __init__(self):
        pass
    def detect_obstacle(self, dist, speed, threshold):
        """Checks if approaching obstacle based on current speed

        Parameters:
            dist: distance measurement from ranging sensor
            speed: current forward speed command
            threshold: obstacle detection range

        Returns:
            obstacleDetected: True if obstacle is detected within range
        """
        obstacleDetected = False

        # (Optional) Implement this function to check for an obstacle
        #  and return "True" if an obstacle is present

        #region: sample implementation
        # if dist - speed < threshold:
        #     obstacleDetected = True
        #endregion
       
        return obstacleDetected


class QBPVision():
    def __init__(self):
        self.imageCriteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)

    def undistort_img(self,distImgs,cameraMatrix,distCoefficients):
        """
        This function undistorts a general camera, given the camera matrix and
        coefficients.
        """

        undist = cv2.undistort(distImgs,
                               cameraMatrix,
                               distCoefficients,
                               None,
                               cameraMatrix)
        return undist

    def df_camera_undistort(self, image):
        """
        This function undistorts the downward camera using the camera
        intrinsics and coefficients."""
        CSICamIntrinsics = np.array([[419.36179672, 0, 292.01381114],
                                     [0, 420.30767196, 201.61650657],
                                     [0, 0, 1]])
        CSIDistParam = np.array([-7.42983302e-01,
                                 9.24162996e-01,
                                 -2.39593372e-04,
                                 1.66230745e-02,
                                 -5.27787439e-01])
        undistortedImage = self.undistort_img(
                                                image,
                                                CSICamIntrinsics,
                                                CSIDistParam
                                                )

        return undistortedImage

    def subselect_and_threshold(self, image, rowStart, rowEnd, minThreshold, maxThreshold):
        """
        This function subselects a horizontal slice of the input image from
        rowStart to rowEnd for all columns, and then thresholds it based on the
        provided min and max thresholds. Returns the binary output from
        thresholding."""

        subImage = image[rowStart:rowEnd,:] # subsection of image we are interested in
        _, binary = cv2.threshold(subImage, minThreshold, maxThreshold, cv2.THRESH_BINARY)

        return binary


class QBPRanging():
    """
        This class uses lidar data from the QBot Platform for obstacle detection
        and ranging."""
    
    def __init__(self):
        pass

    def adjust_and_subsample(self, angles):
        # correct angles data
        angles_corrected = -1*angles + np.pi/2
        # return every 4th sample
        # return ranges[0:end:step], angles_corrected[0:end:step]
        return angles_corrected

    def correct_lidar(self, lidarPosition, ranges, angles):
        """ This function corrects the lidar data for the position of the lidar on the robot

        Parameters:
            lidarPosition: (x,y) position of the lidar on the robot in meters
            ranges: array of lidar ranges
            angles: array of lidar angles in radians
        Returns:
            ranges_c: array of corrected lidar ranges
            angles_c: array of corrected lidar angles in radians
        """

        # Convert lidar data from polar into cartesian, and add lidar position
        x = ranges*np.cos(angles) + lidarPosition[0]
        y = ranges*np.sin(angles) + lidarPosition[1]

        # Convert back into polar coordinates
        ranges_c = np.sqrt(x**2 + y**2)
        angles_c = np.arctan2(y, x)

        return ranges_c, angles_c

    def detect_obstacle(self, ranges, angles, forSpd, forSpdGain, turnSpd, turnSpdGain, minThreshold, obstacleNumPoints):
        """ Checks 90-degree section of current lidar scan for obstacles, 
        where the size and location of the section depends on current speed and 
        turning commands, tunable with parameters
        
        Parameters:
            ranges: lidar scan ranges 
            angles: lidar scan angles 
            forSpd: forward speed command
            forSpdGain: for scaling size of safety threshold 
            turnSpd: turn speed command
            turnSpdGain: for rotation of scan section
            minThreshold: obstacles within this range will be ignored
            obstacleNumPoints: minimum number of lidar points for obstacle detection

        Returns:
            plotRanges: ranges for plotting
            plotAngles: angles for plotting
            obstacleFlag: flag (bool)

       """
        # get total number of lidar points
        numLidarPts = len(ranges)

        # find starting index of 90 degree section of lidar scan, 
        # adjust index for turning command
        startIdx = int(numLidarPts/8) - int(turnSpd*turnSpdGain) 
        # limit to 180 degrees  
        startIdx = np.clip(startIdx, 0, int(numLidarPts/2))
        if forSpd<0: # if moving backwards, look at rear 90 degrees instead of front
            startIdx = startIdx + int(numLidarPts/2) 

        safetyThreshold = np.abs(forSpd)*forSpdGain
        safetyThreshold = np.clip(safetyThreshold, 0.3, 3.5)

        # get lidar data span 
        monitorRanges = ranges[startIdx:startIdx+int(numLidarPts/4)]
        monitorAngles = angles[startIdx:startIdx+int(numLidarPts/4)]

        # define points for safety boundary 
        safetyAngles = monitorAngles
        safetyRanges = safetyThreshold*monitorRanges/monitorRanges
        
        # Total number of obstacles detected between
        # minThreshold & safetyThreshold
        totalObstaclePoints = ((monitorRanges > minThreshold)*(monitorRanges < safetyThreshold)).sum()
        if totalObstaclePoints > obstacleNumPoints:
            obstacleFlag = 1
        else:
            obstacleFlag = 0

        # Return section of current scan and safety boundary for plotting 
        plotRanges = np.append(monitorRanges, safetyRanges)
        plotAngles = np.append(monitorAngles, safetyAngles)

        return plotRanges, plotAngles, obstacleFlag
    
class QBPLocalization():
    """ This class contains the functions for the QBot Platform 
        for localization using lidar data """
    def __init__(self, resolution=20, max_range=5):
        self.lidarScanMatch = Lidar2DMatchScansGrid(resolution=resolution, max_range=max_range)
        self.pose = np.array([0.0,0.0,0.0],dtype=np.float32)
        self.score = np.array([0.0],dtype=np.float32)
        self.covariance = np.eye(3,dtype=np.float32)
        self.prevPose =  np.array([0.0,0.0,0.0],dtype=np.float32)

        self.refRanges = None
        self.refAngles = None
        self.refXY = None
        self.refSaved = False # flag for whether reference scan has been saved 
    
    def save_ref(self, rangesIn, anglesIn):
        """ This function saves input LiDAR data as a reference scan"""
        self.refSaved = False

        if rangesIn is not None and anglesIn is not None:
            
            # save reference scan
            self.refRanges = rangesIn
            self.refAngles = anglesIn

            # set flag 
            self.refSaved = True

            # initialize generator that converts each scan point to Cartesian  
            self.refXY = self.polar_to_cartesian(self.refRanges, self.refAngles)

        return self.refSaved
        
    def polar_to_cartesian(self, rangesIn, anglesIn):
        """ This generator converts polar coordinates
            to Cartesian """
        idx = 0
        while True:
            yield [rangesIn[idx]*np.cos(anglesIn[idx]), 
                   rangesIn[idx]*np.sin(anglesIn[idx])]
            idx = (idx+4)%len(rangesIn)

    def scan_match(self, ranges, angles, transRange=(3.0, 3.0), rotRange=2*np.pi ):
        """ This function checks for a saved reference scan and then runs
            the match method to find the transformation between the current scan"""
        if not self.refSaved:
            return False
        else:
            newMatch = self.lidarScanMatch.match(ref_ranges=self.refRanges, 
                                            ref_angles=self.refAngles, 
                                            num_ref_points = len(self.refRanges),
                                            ranges = ranges, 
                                            angles = angles, 
                                            num_points = len(ranges),
                                            initial_pose = self.prevPose, 
                                            translation_search_range = np.array(transRange, dtype=np.float32), 
                                            rotation_search_range = rotRange,
                                            pose=self.pose, 
                                            score=self.score, 
                                            covariance=self.covariance)
            self.prevPose = self.pose

            # update the next point in the reference scan
            self.refX, self.refY = next(self.refXY)
    
    def terminate(self):
        self.lidarScanMatch.close()


        

    

