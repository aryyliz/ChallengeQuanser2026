#------------------------------------------------------------------------------#
#---------------------Observer - Attitude Estimation---------------------------#
#------------------------------------------------------------------------------#
# Observer for displaying data from attitude_estimation.py

from pal.utilities.probe import Observer

observer = Observer()

observer.add_scope(numSignals=3,
                   name='Yaw Estimation',
                   signalNames=['Yaw Magnetometer (deg)',
                                 'Yaw Gyro (deg)',
                                 'Yaw Complementary (deg)'])

observer.add_scope(numSignals=3,
                   name='Pitch Estimation',
                   signalNames=['Pitch Acc (deg)',
                                 'Pitch Gyro (deg)',
                                 'Pitch Complementary (deg)'])

observer.add_scope(numSignals=3,
                   name='Roll Estimation',
                   signalNames=['Roll Acc (deg)',
                                 'Roll Gyro (deg)',
                                 'Roll Complementary (deg)'])

# observer.add_scope(numSignals=3,
#                    name='Magnetometer',
#                    signalNames=['X',
#                                 'Y',
#                                 'Z',])

observer.launch()