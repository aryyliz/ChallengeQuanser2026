#------------------------------------------------------------------------------#
#--------------------------IMU Attitude Estimation-----------------------------#
#------------------------------------------------------------------------------#
# Measure from IMU and estimate attitude using gyroscope and accelerometer

#===============================================================================
#region: Python imports
#-------------------------------------------------------------------------------
import subprocess
import sys
import os
import math
import numpy as np
import cv2
from pal.utilities.timing import Timer
from pal.products.sensors import SensorsTrainer, SensorsDisplay
from pal.utilities.probe import Probe
from pal.utilities.math import Calculus, wrap_to_pi
from mobile_robot_functions import MDLFusion, MDLDisplayFormat
# endregion 

#===============================================================================
#region: Experiment constants and variables
#-------------------------------------------------------------------------------
SAMPLE_FREQ = 120 # Hz
TOTAL_RUNTIME = 600 # total duration in seconds

IMAGE_SIZE = [800, 480] # lcd display 
HALF_IMG_WIDTH = int(IMAGE_SIZE[0]/2)
HALF_IMG_HEIGHT = int(IMAGE_SIZE[1]/2)
LCD_DISP_FONT = cv2.FONT_HERSHEY_COMPLEX

RAD_TO_DEG = 180/np.pi
DEG_TO_RAD = np.pi/180

counter = 0

accelX, accelY, accelZ = 0,0,0
gyroX, gyroY, gyroZ = 0,0,0
magnetX, magnetY, magnetZ = 0,0,0

rollAcc, rollGyro, pitchAcc, pitchGyro, yawGyro, yawMagnet  = 0, 0, 0, 0, 0, 0
rollFusion, pitchFusion, yawFusion = 0,0,0
initialRoll, initialPitch, initialYaw = None, None, None

# set true or false to display each roll estimate 
plotAcc = True
plotGyro = True
plotFused = True
# endregion

#================================================================++=============
#region: Scope setup 
#-------------------------------------------------------------------------------
probe = Probe(ip = 'localhost')
probe.add_scope(numSignals=3, name='Yaw Estimation')
probe.add_scope(numSignals=3, name='Pitch Estimation')
probe.add_scope(numSignals=3, name='Roll Estimation')

# probe.add_scope(numSignals=3, name='Magnetometer')

subprocess.Popen(
    [sys.executable, 
     os.path.join(os.path.dirname(__file__), 'observer_attitude.py')],
    cwd=os.path.dirname(__file__))
while not probe.connected:
    probe.check_connection()
# endregion


#===============================================================================
#region: Initialization
#-------------------------------------------------------------------------------
fusion = MDLFusion()

# initialize and start generator functions for integration
rollGyroIntegrator = Calculus().integrator(dt = 1/SAMPLE_FREQ)
pitchGyroIntegrator = Calculus().integrator(dt = 1/SAMPLE_FREQ)
yawGyroIntegrator = Calculus().integrator(dt = 1/SAMPLE_FREQ)

next(rollGyroIntegrator)
next(pitchGyroIntegrator)
next(yawGyroIntegrator)

# ******************************* OPTIONAL *************************************
# The code in this section initializes and starts generator functions for 
# complementary filters estimating roll, pitch, and yaw

# Following the implementation of complementary_filter as an example, implement 
# test your own function to fuse the roll/pitch estimates from the gyroscope and
# accelerometer

# Right-click on the function and select "Go to definition" to view the function
# Implement your function in mobile_robot_functions.py

rollCompFilt = fusion.complementary_filter(1/SAMPLE_FREQ)
pitchCompFilt = fusion.complementary_filter(1/SAMPLE_FREQ)
yawCompFilt = fusion.complementary_filter(1/SAMPLE_FREQ)

next(rollCompFilt)
next(pitchCompFilt)
next(yawCompFilt)
# ******************************************************************************

display = MDLDisplayFormat(IMAGE_SIZE[0], IMAGE_SIZE[1])

with (SensorsTrainer() as sensors, 
     SensorsDisplay() as lcd):
    
    timer   = Timer(sampleRate=SAMPLE_FREQ, totalTime=TOTAL_RUNTIME)
    prevTime = timer.get_current_time()
    currentTime= timer.get_current_time()
    while timer.check():
        # get current timestamp
        prevTime = currentTime
        currentTime = timer.get_current_time()
        #endregion

        #=======================================================================
        #region: Read data from IMU
        #-----------------------------------------------------------------------
        sensors.read_outputs()

        # ***************************** PART B *********************************
        # Set the values of gyro_bias to the values from PART A 

        gyroBias = np.array( [0.0136, 0.0068, 0.0898]) # in degrees/s

        # **********************************************************************
        
        # convert gyro data to degrees/s and correct for bias
        gyro = sensors.gyro * RAD_TO_DEG - gyroBias
        gyroX, gyroY, gyroZ = gyro[0], gyro[1], gyro[2]

        # read accelerometer data
        accel = sensors.accelerometer
        accelX, accelY, accelZ = accel[0], accel[1], accel[2]
        # endregion

        #=======================================================================
        #region: Fusion to estimate roll, pitch & yaw angles
        #-----------------------------------------------------------------------

        # calculate roll & pitch angles in deg from acceleration
        rollAcc = (180/np.pi)*math.atan2(accelY,
                                         accelZ) 
        pitchAcc = (180/np.pi)*math.atan2(-accelX,
                                          accelZ) 

        rollGyro = rollGyroIntegrator.send((gyroX))
        pitchGyro = pitchGyroIntegrator.send((gyroY))

        # ***************************** PART C *********************************
        # The code in this section estimates roll and pitch by fusing
        # measurements from the gyroscope and accelerometer using a 
        # complementary filter

        # Uncomment the code in this section to apply the complementary filter.

        # Run the code and tune the parameters kP and kI as needed
        #                              ((rate, correction, kP, kI))
        rollFusion = rollCompFilt.send((gyroX, rollAcc, 2.0, 0.01))
        pitchFusion = pitchCompFilt.send((gyroY, pitchAcc, 2.0, 0.01))

        # **********************************************************************
        #endregion
        
        
        # ******************************* OPTIONAL *****************************
        # Uncomment the code in this section to estimate yaw angle using 
        # magnetometer data

        #=======================================================================
        #region: Estimate Yaw angle using magnetometer data
        #-----------------------------------------------------------------------

        # mag_bias = np.array([4.73e-05, 6.33e-05, 5.33e-05],
        #                      dtype=np.float64)
        # magnetometer = sensors.magnetometer  - mag_bias
        # magnetX, magnetY, magnetZ = magnetometer[0], \
        #                             magnetometer[1], \
        #                             magnetometer[2]

        # yawGyro = yawGyroIntegrator.send((gyroZ))

        # # tilt compensation on X and Y readings
        # magnetXcorrected = magnetX*np.cos(pitchFusion*DEG_TO_RAD) +\
        #                    magnetY*np.sin(rollFusion*DEG_TO_RAD)*np.sin(pitchFusion*DEG_TO_RAD) + \
        #                     magnetZ*np.cos(rollFusion*DEG_TO_RAD)*np.sin(pitchFusion*DEG_TO_RAD)
        # magnetYcorrected = magnetY*np.cos(rollFusion*DEG_TO_RAD) - \
        #                     magnetZ*np.sin(rollFusion*DEG_TO_RAD)
        
        # if initialYaw is None:
        #     initialYaw = math.atan2(magnetYcorrected, magnetXcorrected)

        # # use tilt-compensated magnetometer readings to estimate yaw
        # yawMagnet = RAD_TO_DEG*wrap_to_pi(initialYaw - math.atan2(magnetYcorrected, 
        #                                                          magnetXcorrected))
        
        # yawFusion = yawCompFilt.send((gyroZ, yawMagnet, 2.0, 0.01))
        #endregion
        # **********************************************************************

        #=======================================================================
        #region: Update displays
        #-----------------------------------------------------------------------
    
        # visualize roll estimates only
        # create blank image  
        img = np.zeros([IMAGE_SIZE[1], IMAGE_SIZE[0], 3], dtype=np.uint8)

        # add axes
        cv2.line(img = img, 
                        pt1 = (HALF_IMG_WIDTH, HALF_IMG_HEIGHT-200), 
                        pt2 = (HALF_IMG_WIDTH, HALF_IMG_HEIGHT+200), 
                        color = (100,100,100), 
                        thickness = 2)
        cv2.line(img = img, 
                        pt1 = (HALF_IMG_WIDTH-200, HALF_IMG_HEIGHT), 
                        pt2 = (HALF_IMG_WIDTH+200, HALF_IMG_HEIGHT), 
                        color = (100,100,100), 
                        thickness = 2)
        
        cv2.putText(
            img = img,
            text = 'Roll Angle',
            org = (50, 70),
            fontFace = cv2.FONT_HERSHEY_COMPLEX,
            fontScale = 1.5,
            color = (200,200,200),
            thickness = 2,
            lineType=cv2.LINE_AA
        )

        # visualize roll measurements
        if plotAcc:
            img=display.visualizeAngle(img, rollAcc, 180, (0,0,255))
            cv2.putText(
                img = img,
                text = f"Acc:  {rollAcc: 3.1f}",
                org = (530, 40),
                fontFace = LCD_DISP_FONT,
                fontScale = 1,
                color = (0,0,255),
                thickness = 2,
                lineType=cv2.LINE_AA
            )
            cv2.putText(
                img = img,
                text = f"deg",
                org = (750, 40),
                fontFace = LCD_DISP_FONT,
                fontScale = 0.8,
                color = (0,0,255),
                thickness = 2,
                lineType=cv2.LINE_AA
            )

        if plotGyro:
            img=display.visualizeAngle(img, rollGyro, 140, (150,150,150))
            cv2.putText(
                img = img,
                text = f"Gyro: {rollGyro: 3.1f}",
                org = (530, 80),
                fontFace = LCD_DISP_FONT,
                fontScale = 1,
                color = (150,150,150),
                thickness = 2,
                lineType=cv2.LINE_AA
            )
            cv2.putText(
                img = img,
                text = f"deg",
                org = (750, 80),
                fontFace = LCD_DISP_FONT,
                fontScale = 0.8,
                color = (150,150,150),
                thickness = 2,
                lineType=cv2.LINE_AA
            )

        if plotFused:
            img=display.visualizeAngle(img, rollFusion, 100, (0,255,0))
            cv2.putText(
                img = img,
                text = f"Fused:{rollFusion: 3.1f}",
                org = (530, 120),
                fontFace = LCD_DISP_FONT,
                fontScale = 1,
                color = (0,255,0),
                thickness = 2,
                lineType=cv2.LINE_AA
            )
            cv2.putText(
                img = img,
                text = f"deg",
                org = (750, 120),
                fontFace = LCD_DISP_FONT,
                fontScale = 0.8,
                color = (0,255,0),
                thickness = 2,
                lineType=cv2.LINE_AA
            )

        if counter%5 == 0:
            lcd.draw_image(img)

            probe.send(name = 'Roll Estimation',
                       scopeData = (currentTime, [rollAcc, 
                                                 rollGyro, 
                                                 rollFusion]))
            probe.send(name = 'Pitch Estimation',
                       scopeData = (currentTime, [pitchAcc, 
                                                 pitchGyro, 
                                                 pitchFusion]))
            probe.send(name = 'Yaw Estimation',
                       scopeData = (currentTime, [yawMagnet,
                                                  yawGyro, 
                                                  yawFusion]))
            
            # probe.send(name='Magnetometer',
            #             scopeData=(currentTime, [magnetX, magnetY, magnetZ]))
        #endregion
        counter += 1
        timer.sleep()

input('Press the enter key to exit.')
probe.terminate()
# endregion