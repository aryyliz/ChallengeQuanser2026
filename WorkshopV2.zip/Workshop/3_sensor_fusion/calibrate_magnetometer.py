#------------------------------------------------------------------------------#
#---------------------------Magnetometer calibration---------------------------#
#------------------------------------------------------------------------------#
# Measure magnetometer data and find bias to correct for hard-iron distortions


# *********************** How to perform calibration **************************

# Run this script. While the script is running, slowly rotate the device to
# different orientations in all 3 dimensions. 
# 
# Stop the script and copy the magnetometer bias from the terminal output.

# ****************************************************************************** 

#===============================================================================
#region: Python imports
#-------------------------------------------------------------------------------
import subprocess
import matplotlib.pyplot as plt
import sys
import os
import numpy as np
from pal.utilities.timing import Timer
from pal.products.sensors import SensorsTrainer
from pal.utilities.probe import Probe
# endregion

#===============================================================================
#region: Initialize constants and variables
#-------------------------------------------------------------------------------
sampleRate = 120 # Hz
totalTime = 200 # sec
# endregion

#===============================================================================
#region: Scope setup
#-------------------------------------------------------------------------------
# Scopes for Gyroscope & Accelerometer data
probe = Probe(ip = 'localhost')
probe.add_scope(numSignals=3, name='Magnetometer')
subprocess.Popen(
    [sys.executable, 
     os.path.join(os.path.dirname(__file__), 'observer_magnetometer.py')],
    cwd=os.path.dirname(__file__))
while not probe.connected:
    probe.check_connection()
# endregion

#==============================================================================
#region: Initialization
#-------------------------------------------------------------------------------
with SensorsTrainer() as sensors:
    magData = [[], [], []]
    magDataCorrected = [[], [], []]
    counter = 0
    timer = Timer(sampleRate=sampleRate, totalTime=totalTime)
    #endregion

    while timer.check():
        # get current timestamp
        currentTime = timer.get_current_time()

        #=======================================================================
        #region: Capture and display magnetometer data
        #-----------------------------------------------------------------------
        sensors.read_outputs()
        bias = np.array([0, 0, 0], dtype=np.float64)
        magnetometer = sensors.magnetometer  - bias

        magData[0].append(magnetometer[0])
        magData[1].append(magnetometer[1])
        magData[2].append(magnetometer[2])

        # plot data
        if counter%5 == 0:

            probe.send(name='Magnetometer',
                        scopeData=(currentTime, magnetometer))
        #endregion

        counter += 1
        timer.sleep()

#==============================================================================
#region: Calculate magnetometer bias
#------------------------------------------------------------------------------

print('Analyzing magnetometer data noise: \n')
x_bias = (np.max(magData[0]) + np.min(magData[0]))/2
y_bias = (np.max(magData[1]) + np.min(magData[1]))/2
z_bias = (np.max(magData[2]) + np.min(magData[2]))/2

# print all 3 formatted as an array to 3 significant figures
print('Magnetometer Bias in [X, Y, Z] = ', \
      '[' + ', '.join(f'{v:.3g}' for v in [x_bias, y_bias, z_bias]) + ']')

# correct for hard-iron distortion using the calculated bias
magDataCorrected[0] = np.array(magData[0]) - x_bias
magDataCorrected[1] = np.array(magData[1]) - y_bias
magDataCorrected[2] = np.array(magData[2]) - z_bias
#endregion

#==============================================================================
#region: Plot for visualization
#-------------------------------------------------------------------------------

# create 1 x 3 subplot figure
fig, axs = plt.subplots(1, 3, figsize=(15, 5))

# XY scatter
axs[0].scatter(magData[0], magData[1], 1, label='raw')
axs[0].scatter(magDataCorrected[0], magDataCorrected[1], 1, label='corrected')
axs[0].set_title('XY Directions')
axs[0].set_xlabel('Magnetometer X')
axs[0].set_ylabel('Magnetometer Y')
axs[0].legend(loc = 'lower left', markerscale=5)

# YZ scatter
axs[1].scatter(magData[1],magData[2],1, label='raw')
axs[1].scatter(magDataCorrected[1], magDataCorrected[2], 1, label='corrected')
axs[1].set_title('YZ Directions')
axs[1].set_xlabel('Magnetometer Y')
axs[1].set_ylabel('Magnetometer Z')
axs[1].legend(loc = 'lower left', markerscale=5)

# XZ scatter
axs[2].scatter(magData[0],magData[2],1, label='raw')
axs[2].scatter(magDataCorrected[0], magDataCorrected[2], 1, label='corrected')
axs[2].set_title('XZ Directions')
axs[2].set_xlabel('Magnetometer X')
axs[2].set_ylabel('Magnetometer Z')
axs[2].legend(loc = 'lower left', markerscale=5)

for ax in axs:
    ax.set_aspect('equal', adjustable='box')
    ax.grid('True')
    ax.set_xlim(-1e-4, 1e-4)
    ax.set_ylim(-1e-4, 1e-4)
    ax.ticklabel_format(axis='x', style='sci', scilimits=(0,0))
    ax.ticklabel_format(axis='y', style='sci', scilimits=(0,0))

fig.suptitle('Corrected Magnetometer Data Scatter Plots')
plt.tight_layout()
plt.show()

input('Press the enter key to exit.')
probe.terminate()


# endregion