#------------------------------------------------------------------------------#
#---------------------------Gyroscope calibration------------------------------#
#------------------------------------------------------------------------------#
# Records gyroscope data and prints out mean and std when script is stopped.


# *********************** How to perform calibration **************************

# Place the Sensors Trainer on the metal stand and place it on a table. 
# Run this script and do not the Sensors Trainer. After 30 seconds, the script
# will finish running. 
# 
# Copy the gyro bias in the terminal output.

# ******************************************************************************
  

#===============================================================================
#region: Python imports
#-------------------------------------------------------------------------------
import subprocess
import math
import sys
import os
import statistics as stats
import numpy as np
from pal.utilities.timing import Timer
from pal.utilities.probe import Probe
from pal.products.sensors import SensorsTrainer
# endregion 

#===============================================================================
#region: Initialize constants and variables
#-------------------------------------------------------------------------------
SAMPLE_FREQ = 120 # Hz
TOTAL_RUNTIME = 30 # will run for 30 seconds
RAD_TO_DEG = 180/np.pi

gyroData  = [[], [], []]
accelData = [[], [], []]
counter = 0
# endregion

#==============================================================================
#region: Scope setup 
#------------------------------------------------------------------------------
probe = Probe(ip = 'localhost')
probe.add_scope(numSignals=3, name='Gyroscope')
# probe.add_scope(numSignals=3, name='Accelerometer')
subprocess.Popen(
    [sys.executable, 
     os.path.join(os.path.dirname(__file__), 'observer_gyro_bias.py')],
    cwd=os.path.dirname(__file__))
while not probe.connected:
    probe.check_connection()
# endregion


#==============================================================================
#region: Initialization
#-------------------------------------------------------------------------------
with SensorsTrainer() as sensors:
   
    timer   = Timer(sampleRate=SAMPLE_FREQ, totalTime=TOTAL_RUNTIME)
#endregion

    while timer.check():
        # get current timestamp
        currentTime = timer.get_current_time()

        # get updated sensor measurements
        sensors.read_outputs()

        # **************************** PART A *********************************
        # First run the script with gyroBias set to [0, 0, 0]. 
        # Copy the array of values for gyroBias from the terminal output and 
        # paste it to replace the following line.
        # 
        # Run the script again with the new gyroBias values and verify using
        # the scope display that the gyro is reading close to 0 when the device
        # is not moving.
        
        gyroBias = np.array( [0.0136, 0.0068, 0.0898]) #in degrees

        # *********************************************************************

        gyro = sensors.gyro * RAD_TO_DEG - gyroBias
        accelerometer = sensors.accelerometer

        gyroData[0].append(gyro[0])
        gyroData[1].append(gyro[1])
        gyroData[2].append(gyro[2])

        accelData[0].append(accelerometer[0])
        accelData[1].append(accelerometer[1])
        accelData[2].append(accelerometer[2])

        # plot IMU data
        if counter%5 == 0:
            probe.send(name='Gyroscope',
                        scopeData=(currentTime, gyro))
            # probe.send(name='Accelerometer',
            #             scopeData=(currentTime, accelerometer))

        counter += 1
        timer.sleep()

print('Analyzing IMU data noise: \n')
print('Gyro X:', stats.mean(gyroData[0]), u"\u00B1", stats.stdev(gyroData[0]))
print('Gyro Y:', stats.mean(gyroData[1]), u"\u00B1", stats.stdev(gyroData[1]))
print('Gyro Z:', stats.mean(gyroData[2]), u"\u00B1", stats.stdev(gyroData[2]))

print('\ngyroBias = np.array(', \
      '[' + ', '.join(f'{v:.3g}' for v in [stats.mean(gyroData[0]), 
                                           stats.mean(gyroData[1]), 
                                           stats.mean(gyroData[2])]) + '])')


# print('Accel X:', stats.mean(accelData[0]), u"\u00B1", stats.stdev(accelData[0]))
# print('Accel Y:', stats.mean(accelData[1]), u"\u00B1", stats.stdev(accelData[1]))
# print('Accel Z:', stats.mean(accelData[2]), u"\u00B1", stats.stdev(accelData[2]))

input('Press the enter key to exit.')
probe.terminate()