#------------------------------------------------------------------------------#
#---------------------------Observer - Magnetometer----------------------------#
#------------------------------------------------------------------------------#
# Observer for displaying data from calibrate_magnetometer.py

from pal.utilities.probe import Observer

observer = Observer()

observer.add_scope(numSignals=3,
                   name='Magnetometer',
                   signalNames=['X', 'Y', 'Z'])
observer.launch()